import express from "express";
import path from "path";
import nunjucks from "nunjucks";
const app = express();
const __dirname = path.resolve();
//   __dirname 사용하기 위해서는 path모듈 임포트 필요
// 또한 resolve를 통해 정확히 명시 필요

//view engine set
app.set("view engine", "html");
// main.html을 사용할 때 main이라고 써도 사용가능

// nunjucks
nunjucks.configure("views", {
  watch: true, //html수정될 경우 반영 후 다시 렌더링
  express: app, //express가 선언된 변수명을 다시 입력해야 하는 듯
});
// 경로설정

// middleware
// main page GET
app.get("/", (req, res) => {
  //   res.send("<h1>Hello Main page</h1>");  한 줄의 코드 전송
  //   res.send(`<h1>H1</h1>
  //   <h2>H2</h2>
  //   <h1>H1</h1>
  //   <h2>H2</h2>`);  여러줄은 백틱. 다만 이러한 경우 보통 html 자체를 전송해줌
  res.sendFile(__dirname + "/views/base.html");
  //   위와같이 html을 전송할 경우 페이지마다 html파일이 필요하게 됨
  // 이를 피하기 위해 사용되는것이 template engine. 각 html의 공통된 부분을 묶어 표시해주는 것.
});

app.listen(3000);
// npm install tip
// npm install nodemon -D
// 위와 같이 뒤에 -D옵션을 주게되면, 일반 Dependencies(구동에 필요한 필수 모듈)에 저장되는 것이 아니라,
// devDependencies라는 개발시 필요한 모듈에 저장됨. 실제 구동시에는 적용되지 않음
